from .admin import StripeModelAdmin

# Do not remove: This ensures loading of djstripe.admin.admin
__all__ = ["StripeModelAdmin"]
